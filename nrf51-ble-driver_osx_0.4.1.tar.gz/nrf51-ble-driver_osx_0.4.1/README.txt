######################
nRF51 Bluetooth Smart GATT/GAP Driver for Windows, GNU Linux and OSX
v0.4.1 alpha
######################
Disclaimer: This is an alpha release. No guarantees are given regarding stability or backward compatibility. Interfaces are subject to change.

#####################
Introduction
#####################
The nRF51 Bluetooth Smart GATT/GAP Driver (from now on called the Driver) consists of two (S110 and S120) standard C dynamic libraries that lets a PC application set up and interact with an nRF51 SoftDevice through API function calls. The libraries mirror the nRF51 S110 and S120 SoftDevice APIs and make them available to the PC application.

Commands sent from the libraries are encoded and sent over UART to the nRF51 chip. The connectivity application running on the nRF51 chip decodes the commands and feeds them to the SoftDevice. Command responses and events are encoded and sent from the nRF51 chip to the PC libraries where they are decoded.

The libraries make it possible to create applications on a PC that, in code, are very similar to applications that are running on the nRF51 chip.

Through the use of language bindings the libraries can be used with a number of other languages in addition to native C/C++.

Having this kind of API gives the following benefits:
    - Coherent BLE APIs on a PC and an nRF51 chip.
    - Quickly create prototype and test applications for an nRF51 chip on a PC.
    - Easily migrate code between an nRF51 chip and a PC.
    - Can set up a peer device for a Device Under Test (DUT) using a test script.

#####################
Usage
#####################

This chapter describes important information related to usage of the driver and driver examples.

OSX
------
To be able to run the C and Python examples on OSX you have to set the DYLD_LIBRARY_PATH environment variable to the location of the driver.
This can be done by the following command: export DYLD_LIBRARY_PATH=/Users/nordic/nrf51-ble-driver_darwin_0.0.0/s110:/Users/nordic/nrf51-ble-driver_darwin_0.0.0/s112.
If you do not want to do this manually in each terminal you can add the command to your  ~/.bash_profile file.


#####################
Build details
#####################

WIN32
-----
The Driver libraries have a standard C language interface with CDECL calling convention.
The Driver libraries have been compiled with MinGW GCC toolchain (i686-w64-mingw32-g++, gcc version 4.8.2).

Linux (Ubuntu 14.04.2 LTS)
--------------------------
The Driver libraries are compiled with the system provided C/C++ compiler. The Driver libraries requires that the Boost libraries packaged with the distribution are installed on the system.

Command to install boost:
sudo apt-get install boost1.54

OSX
------
The Driver libraries are compiled with the system provided C/C++ compiler.

#####################
Software bundle contents
#####################
The following is included in the software bundle:

For all platforms:

    Include files (.h)                  Header files with declarations of the functions and types of the library APIs.

    Code examples                       Examples to demonstrate use of the libraries.
                                        C examples are located directly under /examples, with project files for GCC and
                                        MSVC compilers. Examples for language bindings are located under the respective
                                        binding folders, for example /bindings/python/examples.

    Python language bindings            Bindings make it possible to call the libraries from Python 2.7.

    Hex files                           Precompiled connectivity hex files merged with matching softdevices.

    Documentation                       (This file.) Description of the libraries and how to set up
                                        the dependencies.

For Windows:

    Dynamic library binary (.dll)       Binary implementation of the Driver.

    Static import library (.lib)        Object library that points to the corresponding functions
                                        in the dynamic library. Used for compile time function
                                        resolving.

For Linux:
    Dynamic library binary (.so)        Binary implementation of the Driver.

For OSX:
    Dynamic library binary (.dylib)     Binary implementation of the Driver.

#####################
Hardware setup
#####################
The driver supports the following boards:
    pca10028            nRF51422 development kit (v1.0 or higher)
    pca10031            nRF51422 development dongle (v1.0 or higher)

In order for the Driver to operate, a supported board from the list above must be connected to the PC.

The necessary firmware to use this driver can be programmed by just copying connectivity_115k2_with_s110_7.1.0.hex or connectivity_115k2_with_s120_1.0.1.hex file onto the drive your board shows up as. These files contains both the connectivity firmware and SoftDevice.

On Windows you can also use the nRFgo Studio or nrfjprog to program the HEX files.

If you like to compile the connectivity firmware yourself you can do that. The SoftDevice and connectivity firmware source code is found in the nRF51 SDK 7.2.0 (separate download).

#####################
Connectivity application
#####################
The pre-built connectivity HEX files for S110 and S120 are available in their respective 'hex' folders and support the following boards:
    - Development dongles pca10031
    - Development kit pca100028

The connectivity HEX files are configured to use 115200bps(default) and 1Mbps. This baud rate must correspond with the serial port configuration in the Driver application.

The S110 and S120 ble_connectivity projects (ble_central for S120 and ble_peripheral for S110) for these HEX files are available in the nRF51 SDK 7.2.0 (separate download).

To build a hex file for use with the Driver choose the hci version of the connectivity project and do the following modifications.

Required modifications:
    Change the following definitions:
        In ser_phy_config_conn_nrf51.h change UART pins to UART through USB:
            #define SER_PHY_UART_RX RX_PIN_NUMBER
            #define SER_PHY_UART_TX TX_PIN_NUMBER
            #define SER_PHY_UART_CTS CTS_PIN_NUMBER
            #define SER_PHY_UART_RTS RTS_PIN_NUMBER
        In ser_config.h turn off parity:
            #define SER_PHY_UART_PARITY false

Optional changes:
    Baud rate can be changed in ser_config.h:
        #define SER_PHY_UART_BAUDRATE UART_BAUDRATE_BAUDRATE_Baud1M

#####################
Compiling
#####################

WIN32
-----
Compile time resolving
    In order to use the header files and link against the libraries at compile time, a supported C or C++ compiler must be used:

        MSVC (Microsoft Visual C compiler): Requires a static import library in order to resolve the
                                            function calls. A lib file import library is included
                                            with this release.

        GCC/MinGW GCC:                      Can link against the library automatically, this means
                                            no import library is required.

    C/C++ compiler settings:
    Add the Driver include folder to the compiler search path.
    Add the Driver binary folder to the linker search path.

Runtime resolving
The libraries can be called to from a number of other languages when function resolving is done at
runtime. Runtime resolving is done differently in different languages so please refer to the
corresponding language documentation.

Linux
-----
- No special tricks necessary.

#####################
Verifying the setup
#####################
To test and verify that the setup and libraries are working as expected, compile and run:
    - the S110 advertising example. If everything works the example will print "Started advertising". The nRF51 chip will advertise for about 3 minutes. The advertising packets can be discovered with using Master Control Panel or a similar program. The example code advertises with name "Example".
    - the S120 multi link example. If everything works the example will print "Scan started". The application will then print "Successfully connected to: 0x[device_address]" each time it finds a device advertising with the name "Example".

#####################
API reference documentation
#####################
The SoftDevice APIs are documented in the nRF51 SDK documentation:
S110: http://developer.nordicsemi.com/nRF51_SDK/nRF51_SDK_v7.x.x/doc/7.2.0/s110/html/a01076.html
S120: http://developer.nordicsemi.com/nRF51_SDK/nRF51_SDK_v7.x.x/doc/7.2.0/s120/html/a00778.html

The Driver extends the SoftDevice API with some extra functions which are currently documented in the header file sd_rpc.h and through the examples in this release.

Most functions and events from these header files are available:
    - ble.h
    - ble_gap.h
    - ble_gattc.h
    - ble_gatts.h
    - ble_l2cap.h
    - sd_rpc.h

The functions and events not available are:
    - sd_ble_user_mem_reply
    - ble_evt_user_mem_request
    - ble_evt_user_mem_release

Other API entries to note are the sd_ble_evt_get function and the ble_evt_tx_complete event. They are both implemented, but should not be used in any normal use case.

#####################
Language bindings
#####################
Language bindings give the possibility to use the libraries with other languages than C/C++.
See the included binding examples for demonstration on how to use the bindings.
Currently Python bindings are provided, other languages may be added later.

#####################
Included example projects
#####################

=====================
S110 examples
=====================

Advertising
    An example showing how to set up the nRF51 chip to start advertising.
    The application supports connection and service discovery in addition to advertising.

Heart rate monitor
    Example implementation of the Heart Rate profile. When a central device connects to the peripheral and enables CCCD (Client Characteristic Configuration Descriptor), the peripheral starts sending notifications with simulated heart rate values.

=====================
S120 examples
=====================

Multi link
    An example showing how to set up the nRF51 chip to start scanning and connecting to devices.
    The application supports connecting to multiple devices based on their advertised names.

Heart rate collector
    Example implementation of a heart rate collector. Scans for and connects to a peripheral named "Nordic_HRM". After connecting the user can enable the heart rate service CCCD (Client
    Characteristic Configuration Descriptor) causing the notifications to be sent from the peripheral until the CCCD is disabled.

#####################
Known issues
#####################

---------------------
Python bindings
---------------------
    - Application sometimes freezes when termination is attempted.

---------------------
Driver
---------------------
    - SLIP communication sequence numbers between driver and connectivity firmware will come out of sync if the developer does not reset the nRF51 board before calling sd_rpc_open.

#####################
Release notes
#####################
v0.4.1 (April 2015):
    - Added support for OSX (10.9 or newer).
    - Changed default serial port speed back to 115200bps, because of issues with OSX.

v0.4.0 (April 2015):
    - Added support for Ubuntu Linux 14.02.2 LTS (64-bit)
    - Added SoftDevice and Connectivity firmware as one hex file programmable through the JLink storage device.
    - Changed default serial port speed from 115200bps to 1Mbps.
    - Various stability fixes.

v0.3.0 (January 2015):
    - Added support for S120.
    - HEX files with higher baud rates.
    - Added S120 example: multi link.
    - Added S120 example: heart rate collector.
    - Added python bindings S120 example: multi link.
    - Added python bindings S120 example: heart rate collector.

v0.2.0 (September 2014):
    - Supports version 6.0.0 of SDK and version 7.0.0 of S110 softdevice.
    - Changed API from asynchronous to synchronous function calls.

v0.1.0 (April 2014):
    - First public release.
    - Added functions to configure serial port parameters.
    - Added function to specify log file.
    - Added function to specify log message filter.
    - Added function to close serial port and release resources.
    - Added internal resource locking to avoid simultaneous calls to the library.
    - Added timeout for blocking wait function.
    - Added new example: heart rate monitor.
    - Added msvc project files to c examples.
    - Modified directory structure, moved bindings examples to bindings directory.

v0.0.2 (March 2014):
    - Changed API from synchronous to asynchronous function calls.
    - Modified library internals to use asynchronous serialization code base.
    - Added Python bindings.
    - Updated connectivity firmware hex files.

v0.0.1 (February 2014):
    - First pre-release.

Backlog for upcoming releases:
    - Add S130 support. Note: S130 will replace S110 and S120.
    - Add more examples.

#####################
Licenses
#####################
The licenses for the Driver, Driver Bindings and the provided firmware are available in the licenses directory.
